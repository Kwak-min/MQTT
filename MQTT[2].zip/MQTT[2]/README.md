# Gingerbread UDP vs Standard MQTT 연구 모니터링 대시보드

ESP32 2대(1번: Gingerbread UDP, 2번: Standard MQTT)의 **회당 통신 에너지(mJ/mWh)** 를
실시간으로 비교하는 웹 대시보드. 순수 Python 백엔드(FastAPI + paho-mqtt)라
**라즈베리파이 5 (Raspberry Pi OS 64-bit)에서 그대로 동작**한다.

## 기능

| 명세 | 구현 |
|---|---|
| 1. 실시간 에너지 효율 비교 | 회당 소모량(mJ/mWh) 나란히 표시 + 상단에 절감율(%) 강조 배너 |
| 2. 시계열 전력 차트 | 단일 라인 차트(두 보드), 스파이크 필터 토글(초기 Wi-Fi 연결 제외), 누적 수평 막대 |
| 3. 센서/단말 상태 | 1번 보드 ACTIVE/ASLEEP/OFFLINE 배지, BME680 온도·습도·가스 차트, gas_valid 배지, 최신 패킷 JSON 뷰어 |
| 4. 실험 제어 | 전송 주기 동적 변경(프리셋/직접입력, MQTT `experiment/control` 토픽으로 보드에 전파), 로그 Truncate(헤더만 유지), CSV/ZIP 내보내기 |

데이터는 `data/board1_log.csv`, `data/board2_log.csv`에 누적 저장되며
서버 재시작 시 이력을 다시 읽어 차트를 복원한다.

## 라즈베리파이 5 설치 (처음 한 번)

```bash
sudo apt update
sudo apt install -y python3-venv python3-pip mosquitto mosquitto-clients
sudo systemctl enable --now mosquitto     # 브로커를 같은 Pi에서 쓸 경우

mkdir -p ~/mqtt-dashboard && cd ~/mqtt-dashboard
# 이 폴더의 server.py, requirements.txt, static/, deploy/ 를 복사
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

> Pi OS(Bookworm)는 시스템 파이썬에 직접 pip 설치가 막혀 있어(PEP 668) 반드시 venv를 쓴다.

### 브로커를 외부 기기(노트북 등)에서 열 때

`/etc/mosquitto/conf.d/lan.conf`:

```
listener 1883 0.0.0.0
allow_anonymous true
```

```bash
sudo systemctl restart mosquitto
```

## 실행

```bash
# 일반 실행 (MQTT 브로커 구독 모드)
python server.py

# 하드웨어 없이 데모/개발 (가상 패킷 생성, 브로커 불필요)
python server.py --simulate

# 브로커가 다른 장비에 있을 때
MQTT_HOST=192.168.0.10 python server.py
```

접속: `http://<파이 IP>:8000`

### 부팅 시 자동 실행 (systemd)

```bash
sudo cp deploy/mqtt-dashboard.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now mqtt-dashboard
journalctl -u mqtt-dashboard -f   # 로그 확인
```

## ESP32 펌웨어 연동 계약

- **발행 토픽**: `sensors/#` 아래 아무 토픽 (예: `sensors/board1`, `sensors/board2`)
- **보드 구분**: 페이로드 형태로 자동 판별
  - 1번(Gingerbread): `battery`, `nn` 필드 존재
  - 2번(Standard): `device`, `packet_count`, `total_bytes` 필드 존재
- **공통 필드**: `temp, hum, gas, qos, rtt(ms), retry, sleep_r(0~1)`
- **전송 주기 제어**: 보드가 `experiment/control` 토픽을 구독하면 대시보드에서
  주기 변경 시 `{"tx_interval_s": 5, "ts": "..."}` 메시지를 받는다.

## 환경변수

| 변수 | 기본값 | 설명 |
|---|---|---|
| `MQTT_HOST` / `MQTT_PORT` | localhost / 1883 | 브로커 주소 |
| `MQTT_TOPICS` | `sensors/#` | 구독 토픽(쉼표 구분) |
| `CONTROL_TOPIC` | `experiment/control` | 주기 제어 발행 토픽 |
| `VOLT` | 3.3 | 에너지 모델 전압 |
| `I_ACTIVE_MA` / `I_SLEEP_MA` | 240 / 0.8 | 활성/수면 전류 (실측값으로 교체 권장) |
| `OVERHEAD_MS_B1/2` | 0 | 보드별 고정 오버헤드 |
| `SPIKE_ABS_MS` / `SPIKE_MEDIAN_FACTOR` | 200 / 4 | 스파이크 판정 기준 |
| `GAS_MIN` / `GAS_MAX` | 1 / 500 | 가스 유효 범위(kΩ) |
| `TX_INTERVAL_S` | 1 | 초기 전송 주기 |

## 에너지 모델

```
E_tx(mJ)    = V × I_active × (rtt + overhead)          # 송수신 활성 구간
E_sleep(mJ) = V × I_sleep  × sleep_r × interval         # 수면 구간
E_cycle     = E_tx + E_sleep                            # 1회 통신 주기 전체
```

현재 상수는 ESP32 일반값이다. **실제 연구 측정값(전류계/파워프로파일러)으로
`I_ACTIVE_MA`, `I_SLEEP_MA`, `OVERHEAD_MS_*` 를 교체하면 정확도가 올라간다.**

## 디렉터리

```
server.py            # FastAPI 백엔드 (MQTT 구독 + SSE + REST + 시뮬레이터)
static/index.html    # 대시보드 UI (Chart.js 로컬 번들 - 인터넷 불필요)
static/vendor/       # chart.js + date-fns 어댑터
data/                # CSV 로그 (자동 생성)
deploy/              # systemd 유닛
requirements.txt
```
