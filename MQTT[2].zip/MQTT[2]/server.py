"""
Gingerbread(UDP) vs Standard MQTT 연구용 모니터링 대시보드 백엔드.

- MQTT 브로커에서 두 보드의 텔레메트리를 구독해 CSV로 로깅하고
  SSE(Server-Sent Events)로 웹 대시보드에 실시간 푸시한다.
- --simulate 옵션으로 하드웨어 없이 가상 패킷을 생성할 수 있다.

에너지 모델 (ESP32 일반값, 환경변수로 조정 가능):
    E_tx_mJ    = V * I_ACTIVE_mA/1000 * t_active_s * 1000
    t_active_s = rtt_ms/1000 (+ 보드별 오버헤드 OVERHEAD_MS)
    E_sleep_mJ = V * I_SLEEP_mA/1000 * (sleep_r * interval_s) * 1000
    E_cycle_mJ = E_tx_mJ + E_sleep_mJ   (1회 통신 주기 전체)
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import io
import json
import os
import random
import threading
import time
import zipfile
from collections import deque
from datetime import datetime, timezone
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

# ---------------------------------------------------------------- 설정
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
STATIC_DIR = BASE_DIR / "static"
DATA_DIR.mkdir(exist_ok=True)

CFG = {
    "mqtt_host": os.environ.get("MQTT_HOST", "localhost"),
    "mqtt_port": int(os.environ.get("MQTT_PORT", "1883")),
    "mqtt_topics": os.environ.get("MQTT_TOPICS", "sensors/#"),  # 쉼표 구분
    "control_topic": os.environ.get("CONTROL_TOPIC", "experiment/control"),
    # 에너지 모델 상수
    "voltage": float(os.environ.get("VOLT", "3.3")),
    "i_active_ma": float(os.environ.get("I_ACTIVE_MA", "240")),
    "i_sleep_ma": float(os.environ.get("I_SLEEP_MA", "0.8")),
    "overhead_ms_b1": float(os.environ.get("OVERHEAD_MS_B1", "0")),
    "overhead_ms_b2": float(os.environ.get("OVERHEAD_MS_B2", "0")),
    # 스파이크(초기 Wi-Fi 연결 비정상 지연) 판정
    "spike_abs_ms": float(os.environ.get("SPIKE_ABS_MS", "200")),
    "spike_median_factor": float(os.environ.get("SPIKE_MEDIAN_FACTOR", "4")),
    # 가스 센서 유효 범위 (kOhm)
    "gas_min": float(os.environ.get("GAS_MIN", "1")),
    "gas_max": float(os.environ.get("GAS_MAX", "500")),
    "history_max": int(os.environ.get("HISTORY_MAX", "2000")),
}

CSV_HEADER = [
    "ts_iso", "epoch", "board", "temp", "hum", "gas", "battery", "nn",
    "qos", "rtt_ms", "retry", "sleep_r", "packet_count", "total_bytes",
    "e_tx_mj", "e_tx_mwh", "e_cycle_mj", "spike", "gas_valid", "raw_json",
]

state = {
    "interval_s": float(os.environ.get("TX_INTERVAL_S", "1")),
    "mqtt_connected": False,
    "simulate": False,
}
state_lock = threading.Lock()


# ---------------------------------------------------------------- 유틸
def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="milliseconds")


def compute_energy(rtt_ms: float, sleep_r: float, interval_s: float, board: int):
    """1회 통신 에너지 (mJ, mWh) 및 수면 포함 주기 에너지(mJ)."""
    overhead = CFG["overhead_ms_b1"] if board == 1 else CFG["overhead_ms_b2"]
    t_active = max(rtt_ms + overhead, 0.0) / 1000.0
    v = CFG["voltage"]
    e_tx_j = v * (CFG["i_active_ma"] / 1000.0) * t_active
    t_sleep = max(min(sleep_r, 1.0), 0.0) * interval_s
    e_sleep_j = v * (CFG["i_sleep_ma"] / 1000.0) * t_sleep
    e_tx_mj = e_tx_j * 1000.0
    return e_tx_mj, e_tx_mj / 3600.0, (e_tx_j + e_sleep_j) * 1000.0


# ---------------------------------------------------------------- 저장소
class BoardStore:
    def __init__(self, board: int):
        self.board = board
        self.csv_path = DATA_DIR / f"board{board}_log.csv"
        self.history: deque[dict] = deque(maxlen=CFG["history_max"])
        self.latest: dict | None = None
        self.cum_e_mj = 0.0
        self.count = 0
        self._lock = threading.Lock()
        self._ensure_header()
        self._load_history()

    def _ensure_header(self):
        if not self.csv_path.exists() or self.csv_path.stat().st_size == 0:
            with self.csv_path.open("w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(CSV_HEADER)

    def _load_history(self):
        try:
            with self.csv_path.open("r", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
        except OSError:
            return
        for row in rows[-CFG["history_max"]:]:
            try:
                rec = {
                    "ts": row["ts_iso"],
                    "epoch": float(row["epoch"]),
                    "board": self.board,
                    "payload": json.loads(row["raw_json"]),
                    "rtt_ms": float(row["rtt_ms"]),
                    "retry": int(float(row["retry"] or 0)),
                    "sleep_r": float(row["sleep_r"] or 0),
                    "qos": int(float(row["qos"] or 0)),
                    "e_tx_mj": float(row["e_tx_mj"]),
                    "e_tx_mwh": float(row["e_tx_mwh"]),
                    "e_cycle_mj": float(row["e_cycle_mj"]),
                    "spike": row["spike"] == "1",
                    "gas_valid": row["gas_valid"] == "1",
                }
            except (ValueError, KeyError, json.JSONDecodeError):
                continue
            self.history.append(rec)
            self.cum_e_mj += rec["e_tx_mj"]
            self.count += 1
            self.latest = rec

    def append(self, rec: dict):
        with self._lock:
            self.history.append(rec)
            self.latest = rec
            self.cum_e_mj += rec["e_tx_mj"]
            self.count += 1
            p = rec["payload"]
            with self.csv_path.open("a", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow([
                    rec["ts"], f"{rec['epoch']:.3f}", self.board,
                    p.get("temp", ""), p.get("hum", ""), p.get("gas", ""),
                    p.get("battery", ""), p.get("nn", ""),
                    rec["qos"], f"{rec['rtt_ms']:.2f}", rec["retry"],
                    rec.get("sleep_r", ""), p.get("packet_count", ""),
                    p.get("total_bytes", ""),
                    f"{rec['e_tx_mj']:.4f}", f"{rec['e_tx_mwh']:.8f}",
                    f"{rec['e_cycle_mj']:.4f}",
                    "1" if rec["spike"] else "0",
                    "1" if rec["gas_valid"] else "0",
                    json.dumps(p, ensure_ascii=False),
                ])

    def truncate(self):
        with self._lock:
            self.history.clear()
            self.latest = None
            self.cum_e_mj = 0.0
            self.count = 0
            with self.csv_path.open("w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(CSV_HEADER)


stores = {1: BoardStore(1), 2: BoardStore(2)}


def is_spike(board: int, rtt_ms: float) -> bool:
    """초기 Wi-Fi 연결 등 비정상 지연 판정: 절대 임계값 또는 롤링 중앙값의 배수."""
    if rtt_ms >= CFG["spike_abs_ms"]:
        return True
    recent = [r["rtt_ms"] for r in list(stores[board].history)[-20:] if not r["spike"]]
    if len(recent) >= 5:
        med = sorted(recent)[len(recent) // 2]
        if med > 0 and rtt_ms > med * CFG["spike_median_factor"]:
            return True
    return False


# ---------------------------------------------------------------- SSE 브로드캐스트
subscribers: list[asyncio.Queue] = []
sub_lock = threading.Lock()
main_loop: asyncio.AbstractEventLoop | None = None


def broadcast(event: dict):
    with sub_lock:
        subs = list(subscribers)
    for q in subs:
        if main_loop and not q.full():
            main_loop.call_soon_threadsafe(q.put_nowait, event)


# ---------------------------------------------------------------- 인제스트
def classify(payload: dict) -> int | None:
    """페이로드 형태로 보드 구분: 1번(Gingerbread)은 battery/nn, 2번(Standard)은 device/packet_count."""
    if "device" in payload or "packet_count" in payload or "total_bytes" in payload:
        return 2
    if "battery" in payload or "nn" in payload:
        return 1
    return None


def ingest(board: int, payload: dict):
    with state_lock:
        interval = state["interval_s"]
    rtt = float(payload.get("rtt", 0) or 0)
    sleep_r = float(payload.get("sleep_r", 0) or 0)
    e_tx_mj, e_tx_mwh, e_cycle_mj = compute_energy(rtt, sleep_r, interval, board)
    gas = payload.get("gas")
    gas_valid = (
        gas is not None
        and CFG["gas_min"] <= float(gas) <= CFG["gas_max"]
    )
    rec = {
        "ts": now_iso(),
        "epoch": time.time(),
        "board": board,
        "payload": payload,
        "rtt_ms": rtt,
        "retry": int(payload.get("retry", 0) or 0),
        "sleep_r": sleep_r,
        "qos": int(payload.get("qos", 0) or 0),
        "e_tx_mj": e_tx_mj,
        "e_tx_mwh": e_tx_mwh,
        "e_cycle_mj": e_cycle_mj,
        "spike": is_spike(board, rtt),
        "gas_valid": gas_valid,
    }
    stores[board].append(rec)
    broadcast({"type": "packet", "data": rec, "kpi": build_kpi()})


# ---------------------------------------------------------------- KPI
def build_kpi() -> dict:
    out = {"boards": {}, "savings_pct_raw": None, "savings_pct_filtered": None}
    avgs = {}
    avgs_f = {}
    for b in (1, 2):
        st = stores[b]
        hist = list(st.history)
        es = [r["e_tx_mj"] for r in hist]
        es_f = [r["e_tx_mj"] for r in hist if not r["spike"]]
        avgs[b] = sum(es) / len(es) if es else None
        avgs_f[b] = sum(es_f) / len(es_f) if es_f else None
        last_seen = st.latest["epoch"] if st.latest else None
        with state_lock:
            interval = state["interval_s"]
        active = bool(last_seen and (time.time() - last_seen) <= interval * 1.5 + 0.5)
        out["boards"][str(b)] = {
            "count": st.count,
            "cum_e_mj": st.cum_e_mj,
            "cum_e_mwh": st.cum_e_mj / 3600.0,
            "avg_e_mj": avgs[b],
            "avg_e_mj_filtered": avgs_f[b],
            "latest_e_mj": st.latest["e_tx_mj"] if st.latest else None,
            "latest_e_mwh": st.latest["e_tx_mwh"] if st.latest else None,
            "active": active,
            "last_seen": last_seen,
        }
    if avgs[1] and avgs[2]:
        out["savings_pct_raw"] = (1 - avgs[1] / avgs[2]) * 100
    if avgs_f[1] and avgs_f[2]:
        out["savings_pct_filtered"] = (1 - avgs_f[1] / avgs_f[2]) * 100
    return out


# ---------------------------------------------------------------- MQTT
mqtt_client = None


def setup_mqtt():
    global mqtt_client
    import paho.mqtt.client as mqtt

    try:
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    except (AttributeError, TypeError):
        client = mqtt.Client()

    def on_connect(c, userdata, flags, rc, properties=None):
        ok = (rc == 0) or (getattr(rc, "value", 1) == 0)
        with state_lock:
            state["mqtt_connected"] = ok
        if ok:
            for t in CFG["mqtt_topics"].split(","):
                t = t.strip()
                if t:
                    c.subscribe(t)
        broadcast({"type": "mqtt", "connected": ok})

    def on_disconnect(c, userdata, flags, rc, properties=None):
        with state_lock:
            state["mqtt_connected"] = False
        broadcast({"type": "mqtt", "connected": False})

    def on_message(c, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return
        if not isinstance(payload, dict):
            return
        board = classify(payload)
        if board:
            ingest(board, payload)

    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.on_message = on_message
    try:
        client.connect(CFG["mqtt_host"], CFG["mqtt_port"], keepalive=30)
        client.loop_start()
        mqtt_client = client
    except OSError as e:
        print(f"[mqtt] 브로커 연결 실패 ({CFG['mqtt_host']}:{CFG['mqtt_port']}): {e}")
        print("[mqtt] 브로커 없이 대시보드만 실행합니다. --simulate 또는 MQTT_HOST 설정을 사용하세요.")


def publish_interval(seconds: float):
    payload = json.dumps({"tx_interval_s": seconds, "ts": now_iso()})
    if mqtt_client:
        try:
            mqtt_client.publish(CFG["control_topic"], payload, qos=1)
        except Exception as e:  # noqa: BLE001 - 브로커 오류는 로그만
            print(f"[mqtt] 제어 발행 실패: {e}")


# ---------------------------------------------------------------- 시뮬레이터
def simulator(stop_evt: threading.Event):
    rng = random.Random(42)
    boot = {1: True, 2: True}
    pkt = {1: 0, 2: 0}
    batt = 100.0
    while not stop_evt.is_set():
        with state_lock:
            interval = state["interval_s"]
        for board in (1, 2):
            # 초기 Wi-Fi 연결 스파이크: 부팅 직후 1~2회 비정상 지연
            if boot[board]:
                rtt = rng.uniform(400, 900) if rng.random() < 0.7 else rng.uniform(40, 60)
                boot[board] = rng.random() < 0.4
            elif board == 1:
                rtt = rng.gauss(12.3, 2.0)
            else:
                rtt = rng.gauss(45.2, 6.0)
            rtt = max(rtt, 3.0)
            retry = 1 if rng.random() < (0.02 if board == 1 else 0.05) else 0
            sleep_r = min(max(rng.gauss(0.912 if board == 1 else 0.833, 0.01), 0.5), 0.99)
            pkt[board] += 1
            if board == 1:
                batt = max(batt - 0.001, 0)
                payload = {
                    "temp": round(rng.gauss(24.5, 0.4), 2),
                    "hum": round(rng.gauss(50.2, 1.0), 2),
                    "gas": round(rng.gauss(18.5, 0.8), 2),
                    "battery": round(batt, 1),
                    "nn": round(rng.uniform(0, 1), 3),
                    "qos": 0,
                    "rtt": round(rtt, 1),
                    "retry": retry,
                    "sleep_r": round(sleep_r, 3),
                }
            else:
                payload = {
                    "device": "ESP32-Standard-MQTT",
                    "temp": round(rng.gauss(24.5, 0.4), 2),
                    "hum": round(rng.gauss(50.2, 1.0), 2),
                    "gas": round(rng.gauss(18.5, 0.8), 2),
                    "qos": 1,
                    "rtt": round(rtt, 1),
                    "retry": retry,
                    "sleep_r": round(sleep_r, 3),
                    "packet_count": pkt[board],
                    "total_bytes": pkt[board] * 128,
                }
            ingest(board, payload)
        stop_evt.wait(interval)


# ---------------------------------------------------------------- FastAPI
app = FastAPI(title="Gingerbread vs Standard MQTT Monitor")


@app.get("/api/state")
def api_state():
    with state_lock:
        snap = dict(state)
    return {
        "state": snap,
        "config": {
            "voltage": CFG["voltage"],
            "i_active_ma": CFG["i_active_ma"],
            "i_sleep_ma": CFG["i_sleep_ma"],
            "gas_min": CFG["gas_min"],
            "gas_max": CFG["gas_max"],
            "spike_abs_ms": CFG["spike_abs_ms"],
            "control_topic": CFG["control_topic"],
        },
        "kpi": build_kpi(),
        "latest": {
            str(b): (stores[b].latest if stores[b].latest else None) for b in (1, 2)
        },
    }


@app.get("/api/history")
def api_history(board: int = 1, limit: int = 500):
    if board not in stores:
        return JSONResponse({"error": "board must be 1 or 2"}, status_code=400)
    hist = list(stores[board].history)[-max(1, min(limit, CFG["history_max"])):]
    return {"board": board, "records": hist}


@app.post("/api/interval")
async def api_interval(request: Request):
    body = await request.json()
    try:
        seconds = float(body["interval_s"])
    except (KeyError, TypeError, ValueError):
        return JSONResponse({"error": "interval_s (number) required"}, status_code=400)
    if not 0.2 <= seconds <= 3600:
        return JSONResponse({"error": "interval_s must be 0.2..3600"}, status_code=400)
    with state_lock:
        state["interval_s"] = seconds
    publish_interval(seconds)
    broadcast({"type": "interval", "interval_s": seconds})
    return {"ok": True, "interval_s": seconds}


@app.post("/api/truncate")
def api_truncate():
    for b in (1, 2):
        stores[b].truncate()
    broadcast({"type": "truncate"})
    return {"ok": True}


@app.get("/api/export/board{board}.csv")
def api_export_board(board: int):
    if board not in stores:
        return JSONResponse({"error": "board must be 1 or 2"}, status_code=400)
    path = stores[board].csv_path
    return FileResponse(
        path, media_type="text/csv",
        filename=f"board{board}_log_{datetime.now():%Y%m%d_%H%M%S}.csv",
    )


@app.get("/api/export/all.zip")
def api_export_zip():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for b in (1, 2):
            zf.write(stores[b].csv_path, arcname=stores[b].csv_path.name)
    buf.seek(0)
    return StreamingResponse(
        buf, media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="mqtt_logs_{datetime.now():%Y%m%d_%H%M%S}.zip"'},
    )


@app.get("/api/events")
async def api_events(request: Request):
    queue: asyncio.Queue = asyncio.Queue(maxsize=500)
    with sub_lock:
        subscribers.append(queue)

    async def stream():
        try:
            yield f"event: hello\ndata: {json.dumps({'kpi': build_kpi()})}\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=15)
                    yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            with sub_lock:
                if queue in subscribers:
                    subscribers.remove(queue)

    return StreamingResponse(stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")


# ---------------------------------------------------------------- 엔트리
def main():
    parser = argparse.ArgumentParser(description="Gingerbread vs Standard MQTT 모니터링 대시보드")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--simulate", action="store_true",
                        help="하드웨어 없이 가상 패킷 생성 (브로커 연결 생략)")
    args = parser.parse_args()

    global main_loop
    stop_evt = threading.Event()
    sim_thread = None

    if args.simulate:
        state["simulate"] = True
        sim_thread = threading.Thread(target=simulator, args=(stop_evt,), daemon=True)
        sim_thread.start()
        print(f"[sim] 시뮬레이터 시작 - 주기 {state['interval_s']}s")
    else:
        setup_mqtt()

    config = uvicorn.Config(app, host=args.host, port=args.port, log_level="info")
    server = uvicorn.Server(config)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    main_loop = loop
    try:
        loop.run_until_complete(server.serve())
    finally:
        stop_evt.set()
        if sim_thread:
            sim_thread.join(timeout=2)


if __name__ == "__main__":
    main()
